# Options Pro Backend

Angel One SmartAPI + NSE Data Proxy for Options Pro PWA

## Deploy on Render.com (FREE)

1. Fork this repo
2. Go to render.com → New Web Service
3. Connect GitHub → Select this repo
4. Settings:
   - Build Command: `npm install`
   - Start Command: `node server.js`
5. Deploy → Get URL

## API Endpoints

- `GET /` — Health check
- `GET /nifty-spot` — Current Nifty spot price
- `GET /nifty-option-chain` — Full option chain with OI, Volume, IV
- `GET /vix` — India VIX
- `GET /status` — Session status
- `POST /login` — Angel One login
- `POST /logout` — Logout
