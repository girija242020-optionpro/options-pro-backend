const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;

let nseSession = { cookie: '', time: 0 };

async function refreshNSESession() {
  try {
    const r1 = await axios.get('https://www.nseindia.com/', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive'
      },
      timeout: 15000
    });
    const cookies = r1.headers['set-cookie'];
    if (cookies) {
      nseSession.cookie = cookies.map(c => c.split(';')[0]).join('; ');
      nseSession.time = Date.now();
      console.log('NSE Session refreshed OK');
    }
    await axios.get('https://www.nseindia.com/option-chain', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
        'Referer': 'https://www.nseindia.com/',
        'Cookie': nseSession.cookie
      },
      timeout: 15000
    });
  } catch(e) {
    console.log('NSE Session error:', e.message);
  }
}

async function nseAPI(endpoint) {
  if (Date.now() - nseSession.time > 240000 || !nseSession.cookie) {
    await refreshNSESession();
  }
  const resp = await axios.get(`https://www.nseindia.com/api/${endpoint}`, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9',
      'Referer': 'https://www.nseindia.com/option-chain',
      'Connection': 'keep-alive',
      'Cookie': nseSession.cookie,
      'X-Requested-With': 'XMLHttpRequest'
    },
    timeout: 15000
  });
  return resp.data;
}

app.get('/', (req, res) => {
  res.json({
    status: 'Options Pro Backend Running',
    nseSession: !!nseSession.cookie,
    sessionAge: nseSession.time ? Math.floor((Date.now()-nseSession.time)/1000)+'s' : 'none',
    time: new Date().toISOString()
  });
});

app.get('/nifty-option-chain', async (req, res) => {
  try {
    const symbol = (req.query.symbol || 'NIFTY').toUpperCase();
    const data = await nseAPI(`option-chain-indices?symbol=${symbol}`);

    if (!data || !data.records) {
      return res.json({ success: false, message: 'NSE data unavailable' });
    }

    const spot = data.records.underlyingValue;
    const expiries = data.records.expiryDates || [];
    const nearestExpiry = expiries[0];
    const allData = data.filtered?.data || data.records?.data || [];
    const chainData = nearestExpiry ? allData.filter(i => i.expiryDate === nearestExpiry) : allData;

    const strikes = chainData.map(item => ({
      strike: item.strikePrice,
      ce: {
        oi: item.CE?.openInterest || 0,
        oiChange: item.CE?.changeinOpenInterest || 0,
        volume: item.CE?.totalTradedVolume || 0,
        iv: item.CE?.impliedVolatility || 0,
        ltp: item.CE?.lastPrice || 0,
        bid: item.CE?.bidprice || 0,
        ask: item.CE?.askPrice || 0
      },
      pe: {
        oi: item.PE?.openInterest || 0,
        oiChange: item.PE?.changeinOpenInterest || 0,
        volume: item.PE?.totalTradedVolume || 0,
        iv: item.PE?.impliedVolatility || 0,
        ltp: item.PE?.lastPrice || 0,
        bid: item.PE?.bidprice || 0,
        ask: item.PE?.askPrice || 0
      }
    }));

    const totalCeOI = strikes.reduce((s, i) => s + i.ce.oi, 0);
    const totalPeOI = strikes.reduce((s, i) => s + i.pe.oi, 0);
    const pcr = totalCeOI > 0 ? (totalPeOI / totalCeOI).toFixed(2) : '1.0';

    let maxPain = Math.round(spot / 50) * 50;
    let minPain = Infinity;
    strikes.forEach(s => {
      let loss = 0;
      strikes.forEach(t => {
        loss += Math.max(0, t.strike - s.strike) * t.ce.oi;
        loss += Math.max(0, s.strike - t.strike) * t.pe.oi;
      });
      if (loss < minPain) { minPain = loss; maxPain = s.strike; }
    });

    res.json({
      success: true,
      spot, expiry: nearestExpiry,
      expiries: expiries.slice(0, 5),
      pcr, maxPain, totalCeOI, totalPeOI,
      strikes,
      timestamp: new Date().toISOString()
    });

  } catch(e) {
    console.error('Chain error:', e.message, e.response?.status);
    if (e.response?.status === 401 || e.response?.status === 403) {
      nseSession = { cookie: '', time: 0 };
    }
    res.json({ success: false, message: e.message, code: e.response?.status });
  }
});

app.get('/vix', async (req, res) => {
  try {
    const data = await nseAPI('allIndices');
    const vix = data.data?.find(i => i.index === 'INDIA VIX');
    const nifty = data.data?.find(i => i.index === 'NIFTY 50');
    res.json({
      success: true,
      vix: vix?.last || null,
      vixChange: vix?.percentChange || null,
      niftySpot: nifty?.last || null
    });
  } catch(e) {
    res.json({ success: false, message: e.message });
  }
});

app.get('/nifty-spot', async (req, res) => {
  try {
    const data = await nseAPI('allIndices');
    const nifty = data.data?.find(i => i.index === 'NIFTY 50');
    const bank = data.data?.find(i => i.index === 'NIFTY BANK');
    const vix = data.data?.find(i => i.index === 'INDIA VIX');
    res.json({
      success: true,
      spot: nifty?.last || null,
      bankNifty: bank?.last || null,
      vix: vix?.last || null,
      change: nifty?.percentChange || null
    });
  } catch(e) {
    res.json({ success: false, message: e.message });
  }
});

// Refresh session every 3 minutes automatically
setInterval(refreshNSESession, 180000);

refreshNSESession().then(() => {
  console.log('Initial NSE session:', !!nseSession.cookie);
});

app.listen(PORT, () => {
  console.log(`Options Pro Backend running on port ${PORT}`);
});
